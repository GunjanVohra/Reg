package com.cg.project.stepdefinition;

import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.RegistrationPageBean;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {
	private WebDriver driver;
	private  RegistrationPageBean pageBean;

	@Before
	public void setUpTestEnv() {
		System.setProperty("webdriver.chrome.driver","D:\\3000142_Saptarshi_Das\\chromedriver.exe");	
	}

	@Given("^user is accessing the CapBook Registration Page$")
	public void user_is_accessing_the_CapBook_Registration_Page() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		pageBean=PageFactory.initElements(driver, RegistrationPageBean.class);
	}

	@When("^user is trying to submit request after entering valid set of information$")
	public void user_is_trying_to_submit_request_after_entering_valid_set_of_information() throws Throwable {
		pageBean.setEmailId("gunjan1145@gmail.com");
		pageBean.setCity("Pune");
		pageBean.setCountry("India");
		pageBean.setDateOfBirth("04-01-1997");
		pageBean.setFirstName("Gunjan");
		pageBean.setGender("Female");
		pageBean.setLastName("Vohra");
		pageBean.setSecurityAnswer("Gunu");
		pageBean.setSecurityQuestion("Your NickName");
		pageBean.setPassword("1145Gunjan");
		pageBean.setState("Maharastra");
		pageBean.setZipCode("411059");
		pageBean.clickSignUp();

	}

	@Then("^Your Registration has successfully done$")
	public void your_Registration_has_successfully_done() throws Throwable {
		String actualErrorMessage="Your Registration has successfully done";
		String expectedErrorMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);

	}

	@Given("^user is accessing Registration Page$")
	public void user_is_accessing_Registration_Page() throws Throwable {

	}

	@When("^user is trying to submit data without entering 'firstName'$")
	public void user_is_trying_to_submit_data_without_entering_firstName() throws Throwable {
		pageBean.clickSignUp();
	}

	@When("^user is trying to submit data without entering 'lastName'$")
	public void user_is_trying_to_submit_data_without_entering_lastName() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.clickSignUp();
	}

	@When("^user is trying to submit data without entering 'date Of Birth'$")
	public void user_is_trying_to_submit_data_without_entering_date_Of_Birth() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.setLastName("Vohra");
		pageBean.clickSignUp();
	}

	@When("^user is trying to submit data without entering 'gender'$")
	public void user_is_trying_to_submit_data_without_entering_gender() throws Throwable {
		pageBean.setFirstName("Gunjan");
	pageBean.setLastName("Vohra");
	pageBean.setDateOfBirth("04-01-1997");
	pageBean.clickSignUp();
	}

	@When("^user is trying to submit data without 'emailId'$")
	public void user_is_trying_to_submit_data_without_emailId() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.setLastName("Vohra");
		pageBean.setDateOfBirth("04-01-1997");
		pageBean.setGender("Female");
		pageBean.clickSignUp();
	}

	@Then("^'Please fill out this field\\.Must maintain the syntax : someone@email\\.com\\.'$")
	public void please_fill_out_this_field_Must_maintain_the_syntax_someone_email_com() throws Throwable {
		
	}

	@When("^user is trying to submit data without entering 'Password'$")
	public void user_is_trying_to_submit_data_without_entering_Password() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.setLastName("Vohra");
		pageBean.setDateOfBirth("04-01-1997");
		pageBean.setGender("Female");
		pageBean.setEmailId("gunjan1145@gmail.com");
		pageBean.clickSignUp();
	}

	@Then("^'Please match the requested format\\.Must contain at least one number and one uppercase and lowercase letter, and at least (\\d+) or more characters'$")
	public void please_match_the_requested_format_Must_contain_at_least_one_number_and_one_uppercase_and_lowercase_letter_and_at_least_or_more_characters(int arg1) throws Throwable {
		
	}

	@When("^user is trying to submit data without entering 'city'$")
	public void user_is_trying_to_submit_data_without_entering_city() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.setLastName("Vohra");
		pageBean.setDateOfBirth("04-01-1997");
		pageBean.setGender("Female");
		pageBean.setEmailId("gunjan1145@gmail.com");
		pageBean.setPassword("1145gunjan1145");
		pageBean.clickSignUp();
	}

	@Then("^'Please fill out  this field'$")
	public void please_fill_out_this_field() throws Throwable {

	}

	@When("^user is trying to submit data without entering 'state'$")
	public void user_is_trying_to_submit_data_without_entering_state() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.setLastName("Vohra");
		pageBean.setDateOfBirth("04-01-1997");
		pageBean.setGender("Female");
		pageBean.setEmailId("gunjan1145@gmail.com");
		pageBean.setPassword("1145gunjan1145");
		pageBean.setCity("Pune");;
		pageBean.clickSignUp();
	}

	@When("^user is trying to submit data without entering 'Country'$")
	public void user_is_trying_to_submit_data_without_entering_Country() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.setLastName("Vohra");
		pageBean.setDateOfBirth("04-01-1997");
		pageBean.setGender("Female");
		pageBean.setEmailId("gunjan1145@gmail.com");
		pageBean.setPassword("1145gunjan1145");
		pageBean.setCity("Pune");
		pageBean.setState("Maharastra");;
		pageBean.clickSignUp();
	}

	@When("^user is trying to submit data without entering 'zipCode'$")
	public void user_is_trying_to_submit_data_without_entering_zipCode() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.setLastName("Vohra");
		pageBean.setDateOfBirth("04-01-1997");
		pageBean.setGender("Female");
		pageBean.setEmailId("gunjan1145@gmail.com");
		pageBean.setPassword("1145gunjan1145");
		pageBean.setCity("Pune");
		pageBean.setState("Maharastra");
		pageBean.setCountry("India");
		pageBean.clickSignUp();
	
	}

	@When("^user is trying to submit data without entering 'Security Ques'$")
	public void user_is_trying_to_submit_data_without_entering_Security_Ques() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.setLastName("Vohra");
		pageBean.setDateOfBirth("04-01-1997");
		pageBean.setGender("Female");
		pageBean.setEmailId("gunjan1145@gmail.com");
		pageBean.setPassword("1145gunjan1145");
		pageBean.setCity("Pune");
		pageBean.setState("Maharastra");
		pageBean.setCountry("India");
		
		pageBean.clickSignUp();
	}

	@When("^user is trying to submit data without entering 'Security Ques Answer'$")
	public void user_is_trying_to_submit_data_without_entering_Security_Ques_Answer() throws Throwable {
		pageBean.setFirstName("Gunjan");
		pageBean.setLastName("Vohra");
		pageBean.setDateOfBirth("04-01-1997");
		pageBean.setGender("Female");
		pageBean.setEmailId("gunjan1145@gmail.com");
		pageBean.setPassword("1145gunjan1145");
		pageBean.setCity("Pune");
		pageBean.setState("Maharastra");
		pageBean.setCountry("India");
		pageBean.setSecurityQuestion("Your NickName");
		pageBean.clickSignUp();

	}

	@Then("^'Please fill out this field\\.'th JobsWorld\\.com has successfully done plz check your registered email address to activate your account'$")
	public void please_fill_out_this_field_th_JobsWorld_com_has_successfully_done_plz_check_your_registered_email_address_to_activate_your_account() throws Throwable {

	}

}